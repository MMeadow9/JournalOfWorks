import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'users'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)  # АЙДИ
    surname = sqlalchemy.Column(sqlalchemy.String)  # Фамилия
    name = sqlalchemy.Column(sqlalchemy.String)  # Имя
    age = sqlalchemy.Column(sqlalchemy.INTEGER)  # Возраст
    position = sqlalchemy.Column(sqlalchemy.String)  # Должность
    speciality = sqlalchemy.Column(sqlalchemy.String)  # Профессия
    address = sqlalchemy.Column(sqlalchemy.String)  # Адрес
    email = sqlalchemy.Column(sqlalchemy.String, unique=True)  # Эл. почта
    hashed_password = sqlalchemy.Column(sqlalchemy.String)  # Зашифрованные пароль
    modified_date = sqlalchemy.Column(sqlalchemy.DateTime, default=datetime.datetime.now)  # Дата изменения

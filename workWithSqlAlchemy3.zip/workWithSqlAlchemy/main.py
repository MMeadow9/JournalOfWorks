from flask import Flask, render_template
from data.db_session import global_init, create_session
from data.users import User
from data.jobs import Jobs
from data.db_session import *
import datetime
import os


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def load_data():
    if os.path.isfile("db/blogs.db"):
        return
    global_init("db/blogs.db")

    db_sess = create_session()

    for data in [
        ["Scott", "Ridley", 21, "Captain", "research engineer", "module 1", "scott_chief@mars.org"],
        ["Mary", "Elmers", 23, "Second Captain", "main engineer", "module 3-A", "mary_el01@mars.org"],
        ["Miguel", "Lee", 28, "Member", "rover operator, drone pilot", "module 2-Δ", "miguel_lee@mars.org"],
        ["Anthony", "Carrington", 32, "Member", "doctor", "module 2-passage-A-B", "anthony_carr_92@mars.org"],
        ["Arnold", "Smith", 26, "Member", "mechanic", "module 2-Ξ", "Arlnold_Smith98@mars.org"]
    ]:
        user = User()

        name = data[0]
        surname = data[1]
        age = data[2]
        position = data[3]
        speciality = data[4]
        address = data[5]
        email = data[6]

        user.name, user.surname, user.age, user.position, user.speciality, user.address, user.email = (
            name, surname, age, position, speciality, address, email
        )

        db_sess.add(user)

    for data in [
        [1, "Check the serviceability of generators in modules 1 and 2.", 15, "2, 3", datetime.datetime.now(), False],
        [4, "Check the availability of the necessary medicines, check the serviceability of the life support system.", 2, "4", datetime.datetime.now(), True],
        [5, "Fix problems with the tightness of the 3-Ω module.", 6, "5", datetime.datetime.now(), False]
    ]:
        job = Jobs()

        leader = data[0]
        work = data[1]
        work_size = data[2]
        collaborators = data[3]
        start_date = data[4]
        is_finished = data[5]

        job.team_leader, job.job, job.work_size, job.collaborators, job.start_date, job.is_finished = (
            leader, work, work_size, collaborators, start_date, is_finished
        )

        db_sess.add(job)

    db_sess.commit()


load_data()


def main():
    app.run(port=8880, host='127.0.0.1')


@app.route("/")
def journal_of_works():
    global_init("db/blogs.db")

    db_sess = create_session()

    data = []

    for job in db_sess.query(Jobs).all():
        team_leader = [user for user in db_sess.query(User).filter(User.id == job.team_leader)][0]
        data.append(
            [
                job.job,
                f"{team_leader.name} {team_leader.surname}",
                f"{job.work_size} hours",
                job.collaborators,
                "Is finished" if job.is_finished else "Isn't finished"
            ]
        )

    print(data)

    return render_template("journal_of_works.html", data=data)


if __name__ == '__main__':
    main()
